
# This module updates the dataset csv file automatically without having to manually download it from the source.



import os
import requests
from datetime import datetime, timedelta

N_DAYS_AGO = 3

today = datetime.now()
n_days_ago = today - timedelta(days=N_DAYS_AGO)
linkdate = n_days_ago.strftime("%y-%m-%d")
linkdate = '20'+linkdate
count = 0;

## Opens file directory data/ and deletes all contents that ends with csv (Old csv)
for file in os.scandir("dataUpdates/"):
    if file.name.endswith(".csv"):
        os.unlink(file.path)

def parseSite(x, y, z, downloadName, doubleDigit, date) -> int:
  ## Redownload csv file
  link = x+date+y+doubleDigit+z
  r = requests.get(link, allow_redirects=True)
  if(r.status_code == 200):
    ## Grabs vac_distribution
    open('dataUpdates/'+downloadName+'.csv', 'wb').write(r.content)
    print("Success:\n\tFound: {}".format(downloadName))
    return 1
  return 0

## Redownload csv file


for i in range(10):
  for j in range (10):
    randomDoubleDigit = str(i)+str(j)
    print(randomDoubleDigit)


   # .csv file
    count = count + parseSite('https://s3.us-east-2.amazonaws.com/data.opencovid.ca/archive/on/hospitalizations-and-cases-by-vaccination-status/vac_status_', '_22-', '.csv', 'hospitalizations-and-cases-by-vaccination-status', randomDoubleDigit, linkdate)




    if(count == 1):
      print("All Files Found")
      exit()
print("Some files are missing")