
import sys

import pandas as pd

import seaborn as sns

from matplotlib import pyplot as plt
from matplotlib import ticker as ticktools


# This script makes a line graph of the data from the hospitalizations-and-cases-by-vaccination-status.csv
# It is useful as it can help us visualize the differences in covid-19 cases amongst unvaccinated and vaccinated people over time in Ontario.






def main(argv):
    if len(argv) != 3:
        print("Number of arguments is not correct")
        sys.exit(-1)
    data_file_to_read = argv[1]
    plot_file_to_create = argv[2]

    try:
        csv_df = pd.read_csv(data_file_to_read)


    except IOError as err:
        print("Unable to open sourcefile", csv_df,
              ": {}".format(err), file=sys.stderr)
        sys.exit(-1)

    # Create matplotlib data enviroment
    fig = plt.figure()

    # This creates a lineplot using seaborn.  We simply refer to
    # the various columns of data we want in our pandas data structure.

    # Can make y and x to vary
    # To vary y - change to cases_unvac_rate_per100K
    #ax = sns.barplot(x="Date", y="cases_full_vac_rate_per100K", data=csv_df)

    # ax = sns.lineplot(x="Date", y="cases_full_vac_rate_per100K",  data=csv_df)

    ax = sns.lineplot(x="cases_full_vac_rate_per100K", y="cases_unvac_rate_per100K",  data=csv_df)

    # X axis 8 ticks
    ax.xaxis.set_major_locator(ticktools.MaxNLocator(9))

    # X axis 45deg tilt
    plt.xticks(rotation=45, ha='right')

    # saving to a file
    fig.savefig(plot_file_to_create, bbox_inches="tight")


main(sys.argv)